package com.masai.creational_pattern.factory;

public interface ComputerAbstractFactory {

	public Computer createComputer();
}
