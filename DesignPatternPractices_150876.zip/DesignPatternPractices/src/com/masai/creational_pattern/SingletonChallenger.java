package com.masai.creational_pattern;

import java.lang.reflect.Constructor;

public class SingletonChallenger {
	
	public static void main(String[] args) throws Exception{
		SimpleSingleton singleton1 = SimpleSingleton.getInstance();
		
		SimpleSingleton singleton2 = null;
		 
		Constructor[] constructors = SimpleSingleton.class.getDeclaredConstructors();
		
		for(Constructor constructor : constructors) {
			constructor.setAccessible(true);
			singleton2 = (SimpleSingleton)constructor.newInstance();
			break;
		}
		
		System.out.println(singleton1.hashCode());
		System.out.println(singleton2.hashCode());
		
	}

}
