package com.masai.creational_pattern.bridge;

public interface Color {

	public void applyColor();
	
}
