package com.masai.creational_pattern.bridge;

public abstract class Shape {

	//composition of Color interface
	protected Color color;
	
	//setting implementor of Color
	public Shape(Color color) {
		this.color = color;
	}
	
	public abstract void applyColor();
}
