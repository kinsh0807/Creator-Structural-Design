package com.masai.creational_pattern.bridge;

public class Circle extends Shape implements AnotherOperations{

	public Circle(Color c) {
		super(c);
	}

	@Override
	public void applyColor() {
		System.out.println("Circle filled with color");
		color.applyColor();
	}

	@Override
	public void feature1() {
		System.out.println("Circle specific feature by AnotherOperation interface");
	}
	
	
	
}
