package com.masai.creational_pattern;

public class AnotherSingleton {
	
	private AnotherSingleton() {}
	
	private static class SingletonHelper {
		private static final AnotherSingleton instance = new AnotherSingleton();
	}
	
	public static AnotherSingleton getInstance() {
		return SingletonHelper.instance;
	}

}
